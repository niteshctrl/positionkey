# __init.py__

# Version of the package
__version__ = "0.0.1"